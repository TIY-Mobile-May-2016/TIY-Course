//
//  Artist.m
//  SpotifyTest
//
//  Created by Phil Wright on 6/7/16.
//  Copyright © 2016 Touchopia, LLC. All rights reserved.
//

#import "Artist.h"

@implementation Artist

-(instancetype) initWithDictionary:(NSDictionary *)dict {
    
    if ( (self = [super init])) {
        
    }
    return self;
}


@end

