//
//  Artist.h
//  SpotifyTest
//
//  Created by Phil Wright on 6/7/16.
//  Copyright © 2016 Touchopia, LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Artist : NSObject

-(instancetype) initWithDictionary:(NSDictionary *)dict;

@property (nonatomic,strong) NSString *artistId;
@property (nonatomic,strong) NSString *name;

@end
